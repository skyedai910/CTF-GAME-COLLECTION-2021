import re 
import os
import hashlib
import random

def md5(s):
    return hashlib.md5(s.encode()).hexdigest()

def stop():
    print("[-] oh god please no")
    exit(0)

def cal():
    op = ['+', '-', '*', '/']
    s = ''
    for _ in range(5):
        s += f"{random.randint(10000,99999)}{op[random.randint(0,3)]}"
    s += f"{random.randint(10000,99999)}"
    return (s+'=\n', int(eval(s)))

def loadconfig(name=False):
    if not os.path.exists('/tmp/config'):
        os.makedirs('/tmp/config')
    if name:
        conf_file = input("[*] please input the config filename:\n>>> ")
        if ".." in conf_file:
            stop()
        conf = os.path.join('/tmp/config/', conf_file)
        try:
            with open(conf, 'r') as f:
                conf_name = f.readline().replace('\n', '')
        except Exception as e:
            print("[-]", e)
            exit(0)
        if re.match(f"^{name}$", conf_name) and name == conf_name:
            return conf_file
        else:
            stop()
    conf_file = md5(repr(random.random()))
    print(f"[*] Remember Your Config file is /tmp/config/{conf_file}")
    return conf_file

def start(name, conf_file):
    banner = '''
    I'll give you some questions, input the answer to me!
    If you wanna stop, just input: !wq

    OK Let's start!
    '''
    print(banner)
    score = 0
    file = os.path.join('/tmp/config/', conf_file)
    if not os.path.exists(file):
        with open(file, 'w') as f:
            f.write(f'{name}\n')
    else:
        score = int(open(file, 'r').read().split('\n')[1])

    while True:
        question, answer1 = cal()
        print("   " + question)
        userinput = input("[*] Your answer?\n>>>")
        if userinput == '!wq':
            break
        answer2 = int(userinput)
        if answer1 == answer2:
            score += 10
            print("[+] Correct! score+10\n")
        else:
            score -= 10
            print("[+] Sorry~ score-10\n")
    
    print(f"[*] Your score is {score}")
    with open(file, 'w') as f:
        f.write(f"{name}\n{score}")


def main():
    banner = '''
    [1] start game
    [2] quit
    '''
    print(banner)
    choice = int(input('[*] Your choice?\n>>>'))
    if choice != 1:
        stop()

    banner = '''
    [1] I'm new on this game
    [2] I have a game config archive
    '''
    print(banner)
    choice = int(input('[*] Your choice?\n>>>'))    
    if choice == 1:
        name = input('[*] What\'s your name?\n>>>')
        conf_file = loadconfig()
        if not re.match(r'^[a-zA-Z0-9]{,32}$', name):
            stop()
    elif choice == 2:
        name = input('[*] What\'s your name?\n>>>')
        conf_file = loadconfig(name)
    else:
        stop()
    start(name, conf_file)

if __name__ =='__main__':
    main()