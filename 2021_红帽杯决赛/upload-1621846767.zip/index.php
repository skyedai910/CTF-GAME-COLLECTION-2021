<?php

include('class.php');
if(!(isset($_SESSION['func']))) {
    $_SESSION['func'] = 'showfile';
}
if(!(isset($_SESSION['files']))) {
    $_SESSION['files'] = array();
}
if(!(isset($_SESSION['paths']))) {
    $_SESSION['paths'] = array();
}

if(isset($_POST['filename'])&&isset($_POST['content'])){
    if(stristr($_POST['filename'], 'h')){
        die('no h!');
    }
    $filepath = './files/'.$_POST['filename'];
    $filename = basename($_POST['filename']);
    file_put_contents($filepath,$_POST['content']);
    $_SESSION['files'][$filename] = $filepath;
    $_SESSION['paths'][$filepath] = 'file';
    header('Location:/?file='.$filename);

}
?>
<!DOCTYPE html>
<html>
<head>
    <title>upload</title>
</head>
<body>
<div>
    <h3>upload your file below</h3>
    <form action="index.php" method="post">
        <input type="text" name="filename" value="filename" style="width: 600px;">
        </br>
        </br>
        <textarea type="text" name="content" style="width: 600px;height: 300px;" ></textarea>
        </br>

        <input type="submit" value="submit">
    </form>
    <h4>beatiful front</h4>
</div>
<?php
if(rand(0,2)>1){
    $showfile = 'red';
}
else{
    $showfile ='green';
}
$filelist = array();
foreach ($_SESSION['paths'] as $path=>$class){
    $temp = new $class($path);
    if($class=='file'){
        $filelist[] = (string)$temp;
    }
    else{
        $filelist[] = $temp;
    }
}
$out = '<p>your file:';

foreach ($filelist as $value){
    $out .= $value.' ';
}
echo $out.'</p>';

if(isset($_GET['file'])){
    if(isset($_SESSION['files'][$_GET['file']])) {

        $pathinfo = array($_GET['file']=>$_SESSION['files'][$_GET['file']]);
        ${$_SESSION['func']}($pathinfo);
    }
    else{
        echo 'no such file!';
    }
}
?>
</body>
</html>

