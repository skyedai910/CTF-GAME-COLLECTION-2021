//流程模块【wenjuan.调查问卷】下录入页面自定义js页面,初始函数
function initbodys(){
	
}

function changesubmit(d){
	if(d.enddt<d.startdt)return '截止日期必须大于开始日期';
	
}
