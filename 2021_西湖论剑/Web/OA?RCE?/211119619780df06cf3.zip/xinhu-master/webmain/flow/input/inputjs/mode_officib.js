//初始函数
function initbodys(){
	$('#inputtitle').css('color','red');
	$('body').append('<style>.ys1,.ys2{border-color:red;color:red}</style>');
	
	form('unitsame').readOnly=false;
}