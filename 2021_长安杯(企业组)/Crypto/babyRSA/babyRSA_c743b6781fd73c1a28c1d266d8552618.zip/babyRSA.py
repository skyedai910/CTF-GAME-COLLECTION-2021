from Crypto.Util.number import *
import random
from secret import flag

def getMyPrime(nbits,k):
    b = getRandomNBitInteger(nbits)
    P = k*b*b+1
    while P%4 or not isPrime(P//4):
        b = getRandomNBitInteger(nbits)
        P = k*b*b+1
    return P//4

p = getMyPrime(500,27)
q = getMyPrime(500,43)
r = getMyPrime(500,59)
n = p*q*r
print(n)
m1 = int(input())%n
m2 = int(input())%n
e = 65537
c1 = long_to_bytes(pow(m1,e,n))[:128]
c2 = long_to_bytes(pow(m2,e,n))[:128]
if((m1!=m2)&(c1==c2)):
    print(pow(bytes_to_long(flag),e,q*r))
else:
    print(getRandomNBitInteger((q*r).bit_length()))
