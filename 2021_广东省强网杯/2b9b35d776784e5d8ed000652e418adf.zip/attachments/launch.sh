#!/bin/sh

timeout -s SIGKILL 120s ./qemu-system-i386 -hda ./disk -fdb ./flag -snapshot -nographic -monitor /dev/null
