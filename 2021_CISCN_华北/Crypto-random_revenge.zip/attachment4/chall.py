from Crypto.Util.number import bytes_to_long
import random

res = []
flag = b"find me"

assert len(flag) == 28

res.append(random.getrandbits(128) ^ bytes_to_long(flag[:14]))

for i in range(1, 48):
    res.append(random.getrandbits(32*i))

res.append(random.getrandbits(128) ^ bytes_to_long(flag[14:]))

with open("data.txt", "w") as f:
    for i in res:
        f.write(str(i)+"\n")