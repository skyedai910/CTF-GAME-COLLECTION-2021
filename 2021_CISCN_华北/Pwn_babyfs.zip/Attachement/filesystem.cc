#include "filesystem.h"

#define PTR_ADD(ptr, val) ((char*)(ptr) + (val))

void die(const char* msg) {
    puts(msg);
    exit(-1);
}

void 
FileSystem::CheckFileInode(INode *inode) {
    if (inode->start_block >= BITMAP_BITS)
        die("?");
    if (inode->start_block + inode->block_num >= BITMAP_BITS)
        die("?");
    if (inode->size >= inode->block_num * block_size)
        die("?");
}

void 
FileSystem::CheckDirInode(INode *inode) {
    if (inode->start_block >= BITMAP_BITS)
        die("?");
    auto items = ReadDirInode(inode);
    for (auto &item : items) {
        if (item.inode_num >= inode_number)
            die("?");
        INode *sub_inode = &inode_start[item.inode_num];
        if (sub_inode->type == FILE_TYPE)
            CheckFileInode(sub_inode);
    }
}

void
FileSystem::CheckDisk() {
    INode *ptr = inode_start;
    for (int i = 0; i < inode_number; i++) {
        INode *inode = &inode_start[i];
        if (inode->size && inode->block_num) {
            if (inode->type == FILE_TYPE)
                CheckFileInode(inode);
            else 
                CheckDirInode(inode);
        }
    }
}

void
FileSystem::Mount() {
    disk = new char[128 * 10 + BITMAP_BITS * 128];
    if (!disk)
        die("new fail");
    cout << "input data> ";
    read(0, disk, 1024*1024 - 1);

    auto sb = (SuperBlock*)disk;
    if (sb->magic != FS_MAGIC)
        die("unknown type");

    block_size = sb->block_size;
    if (block_size != 128)
        die("not support");
    uint32_t inode_block_number = sb->inode_block_num;
    if (inode_block_number > 8)
        die("not support");
    
    inode_number = (inode_block_number * block_size) / sizeof(INode);

    inode_start = (INode*)PTR_ADD(disk, block_size);
    bitmap = (BitMap*)PTR_ADD(inode_start, inode_block_number * block_size);
    data_start = PTR_ADD(bitmap, block_size);

    uint32_t root_inode_idx = sb->root_inode;
    cur_inode = root_inode = (INode*)PTR_ADD(inode_start, root_inode_idx * block_size);
    parent_dir = nullptr;
    CheckDisk();
}


void
FileSystem::ListDir() {
    auto dir_item = ReadDirInode(cur_inode);
    string res;
    for (auto &item : dir_item) {
        res += item.name;
        res += " ";
    }
    cout << res << endl;
}


vector<DirItem> 
FileSystem::ReadDirInode(INode *inode) {
    auto data = (DirItem*)PTR_ADD(data_start, inode->start_block * block_size);
    vector<DirItem> res;
    for (int i = 0; i < inode->size / sizeof(DirItem); i++) {
        res.push_back(data[i]);
    }
    return res;
}

string
FileSystem::ReadFileInode(INode *inode) {
    auto data = (char*)PTR_ADD(data_start, inode->start_block * block_size);
    string res(data, data + inode->size);
    return res;
}


uint64_t
FileSystem::ReadBitmapIndex(uint64_t index) {
    if (index >= BITMAP_BITS)
        return 1;
    uint32_t bitmap_idx = index / 64;
    uint32_t inner_idx = index % 64;

    uint64_t target = bitmap->bitmap[bitmap_idx];
    target = (target >> inner_idx);
    target = target & 1;
    return target;
}

void 
FileSystem::WriteBitmapIndex(uint64_t index,uint64_t value) {
    if (index >= BITMAP_BITS)
        return;
    uint32_t bitmap_idx = index / 64;
    uint32_t inner_idx = index % 64;
    bitmap->bitmap[bitmap_idx] |= (value << inner_idx);
}

uint32_t
FileSystem::FindFreeDataBlock(int num) {
    int start;
    for (start = 0; start < BITMAP_BITS; start++) {
        if (!ReadBitmapIndex(start)) {
            bool is_ok = true;
            for (int j = start; j < start + num; j++) 
                if (ReadBitmapIndex(j))
                    is_ok = false;
            if (is_ok) {
                for (int j = start; j < start + num; j++)
                    WriteBitmapIndex(j, 1);
                return start;
            }
        }
    }
    return 0;
}

uint32_t 
FileSystem::FindFreeInode() {
    auto ptr = inode_start;
    for (int i = 0; i < inode_number; i++) {
        if (!ptr[i].block_num && !ptr[i].size)
            return i;
    }
    return 0;
}

bool 
FileSystem::CheckFileNameLength(string &name) {
    if (name.length() >= 20)
        return false;
    return true;
}

bool 
FileSystem::CreateNew(string name, uint32_t new_size, FileType type) {
    if (!CheckFileNameLength(name))
        return false;
    uint32_t size = cur_inode->size;
    if (size >= block_size)
        return false;
    auto data = (DirItem*)PTR_ADD(data_start, cur_inode->start_block * block_size);
    data += cur_inode->size / sizeof(DirItem);
    strcpy(data->name, name.c_str());
    uint32_t inode_index = FindFreeInode();
    if (!inode_index) {
        puts("no free inode to use");
        return false;
    }
    data->inode_num = inode_index;
    cur_inode->size += sizeof(DirItem);
    INode *inode = &inode_start[inode_index];
    inode->block_num = ((new_size + block_size - 1)&(~(block_size-1)))/block_size;
    inode->mode = 6;
    inode->size = new_size;
    inode->start_block = FindFreeDataBlock(inode->block_num);
    inode->type = type;
    return true;
}

void 
FileSystem::CreateNewDir(string name) {
    if (name[name.length() - 1] != '/')
        name += '/';
    if (!CreateNew(name, block_size, DIR_TYPE)) {
        cout << "can't create new dir" << endl;
    }
}

void 
FileSystem::CreateNewFile(string name, uint32_t size) {
    if (!CreateNew(name, size, FILE_TYPE)) {
        cout << "can't create new file" << endl;
    }
}

INode*
FileSystem::FindFileInodeFromName(string name) {
    auto items = ReadDirInode(cur_inode);
    uint32_t target_inode_index = 0;
    for (auto &item : items) {
        if (!strcmp(item.name, name.c_str())) {
            target_inode_index = item.inode_num;
            break;
        }
    }
    if (target_inode_index) {
        INode *inode = &inode_start[target_inode_index];
        return inode;
    }
    return nullptr;
}

void 
FileSystem::ReadFile(string name) {
    auto inode = FindFileInodeFromName(name);
    if (inode) {
        if (inode->type != FILE_TYPE) {
            cout << name << " is dir" << endl;
            return;
        }
        string content = ReadFileInode(inode);
        cout << content << endl;
    } else {
        cout << name << "is not found" << endl;
        return;
    }
}

void 
FileSystem::WriteFile(string name, string content) {
    auto inode = FindFileInodeFromName(name);
    if(inode) { 
        if (inode->type != FILE_TYPE) {
            cout << name << " is dir" << endl;
            return;
        }
        if (content.length() > inode->size) {
            cout << "content is tooo long" << endl;
            return;
        }
        auto data = (char*)PTR_ADD(data_start, inode->start_block * block_size);
        memcpy(data, content.c_str(), content.length());
    } else {
        cout << name << "not found" << endl;
    }
}

void 
FileSystem::ExecuteFile(string name) {
    auto inode = (INode*)FindFileInodeFromName(name);
    if (inode) {
        if (inode->type != FILE_TYPE) {
            cout << name << " is dir" << endl;
            return;
        }
        string content = ReadFileInode(inode);
        auto ptr = (ExecFileHeader*)content.c_str();
        if (ptr->magic != EXEC_FILE_MAGIC)
            die("unknown file format");
        if (ptr->code_len >= content.length() - sizeof(ExecFileHeader))
            die("?");
        if (ptr->code_offset >= content.length())
            die("?");
        if (ptr->run_run_run_run == (uint64_t)stdin) {
            cout << "run..." << endl;
            void *exec_ptr = mmap(0, 0x1000, 7, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
            if (exec_ptr == MAP_FAILED)
                die("mmap fail");
            memcpy(exec_ptr, (char*)ptr + ptr->code_offset, ptr->code_len);
            ((void (*)())exec_ptr)();
        }
    } else {
        cout << "command <" << name << "> is not found" << endl;
    }
}

void 
FileSystem::ChangeDir(string name) {
    if (name[name.length() - 1] != '/')
        name += '/';
    if (name == "../" && parent_dir) {
        cur_inode = parent_dir;
        if (cur_inode == root_inode)
            parent_dir = nullptr;
        return;
    }
    if (name == "./")
        return;
    INode *inode = FindFileInodeFromName(name);
    if (!inode) {
        cout << name << " is not found" << endl;
        return;
    }
    if (inode->type != DIR_TYPE) {
        cout << name << " is not a dir" << endl;
        return;
    }
    parent_dir = cur_inode;
    cur_inode = inode;
}
