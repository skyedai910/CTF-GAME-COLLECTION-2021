from Crypto.Util.number import getPrime
import hashlib
from random import getrandbits
from sm4 import CryptSM4
import socketserver
from base64 import b64encode

###
#
# ......
###


while True:
    a = getrandbits(256)
    m = int(str(bin(a))[2:len(bin(a)) - 32] + "0" * 32, 2)

    b = getrandbits(256)
    g = 3
    p = getPrime(256)

    pub_alice = pow(g, a, p)
    pub_bob = pow(g, b, p)
    req.sendall(b"m: "+bytes(str(m),encoding='utf-8')+b'\n')
    req.sendall(b"p: "+bytes(str(p),encoding='utf-8')+b'\n')
    req.sendall(b"A: "+bytes(str(pub_alice),encoding='utf-8')+b'\n')
    a = 0
    # wait for user input
    resp = req.recv(1024).decode().strip('\n')
    a = int(resp)
    sharesecret_user = pow(pub_bob, a, p)
    sharesecret = pow(pub_alice, b, p)

    if(sharesecret_user != sharesecret):
        req.sendall("Oops! Bye~~")
        req.close()

    req.sendall(b"The Public Key of Bob is: " + bytes(str(pub_bob),encoding='utf-8') + b"\n")
    with open('flag.txt', 'rb') as f:
        flag = f.read()
    # encrypt data
    sm4 = CryptSM4()
    sm4_key = hashlib.md5(bytes(str(sharesecret),encoding='utf-8')).hexdigest().encode()
    sm4.set_key(sm4_key, 0)
    flag = b64encode(sm4.crypt_ecb(flag))
    req.sendall(b"The Encrypted Flag is: " + flag + b"\n")

##
# ...
# ...
##
#

server.timeout = 60