
extern zend_class_entry *stub_unknownclass_ce;

ZEPHIR_INIT_CLASS(Stub_UnknownClass);

