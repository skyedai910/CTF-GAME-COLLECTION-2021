
extern zend_class_entry *stub_ooimpl_zbeginning_ce;

ZEPHIR_INIT_CLASS(Stub_OoImpl_ZBeginning);

