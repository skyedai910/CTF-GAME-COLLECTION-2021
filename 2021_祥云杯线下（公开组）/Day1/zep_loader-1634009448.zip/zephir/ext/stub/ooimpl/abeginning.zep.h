
extern zend_class_entry *stub_ooimpl_abeginning_ce;

ZEPHIR_INIT_CLASS(Stub_OoImpl_ABeginning);

