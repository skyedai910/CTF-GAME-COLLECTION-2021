
extern zend_class_entry *stub_constantsparent_ce;

ZEPHIR_INIT_CLASS(Stub_ConstantsParent);

