
extern zend_class_entry *stub_pdostatement_ce;

ZEPHIR_INIT_CLASS(Stub_PdoStatement);

