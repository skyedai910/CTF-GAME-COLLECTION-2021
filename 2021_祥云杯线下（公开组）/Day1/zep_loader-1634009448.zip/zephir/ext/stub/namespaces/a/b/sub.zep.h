
extern zend_class_entry *stub_namespaces_a_b_sub_ce;

ZEPHIR_INIT_CLASS(Stub_Namespaces_A_B_Sub);

