
extern zend_class_entry *stub_oo_param_ce;

ZEPHIR_INIT_CLASS(Stub_Oo_Param);

