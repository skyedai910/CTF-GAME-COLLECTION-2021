
extern zend_class_entry *stub_oo_extend_db_exception_ce;

ZEPHIR_INIT_CLASS(Stub_Oo_Extend_Db_Exception);

