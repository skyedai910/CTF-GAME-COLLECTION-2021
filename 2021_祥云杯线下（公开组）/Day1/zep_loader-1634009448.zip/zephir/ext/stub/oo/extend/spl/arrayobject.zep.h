
extern zend_class_entry *stub_oo_extend_spl_arrayobject_ce;

ZEPHIR_INIT_CLASS(Stub_Oo_Extend_Spl_ArrayObject);

