
extern zend_class_entry *stub_extendedinterface_ce;

ZEPHIR_INIT_CLASS(Stub_ExtendedInterface);

