
extern zend_class_entry *stub_10__closure_ce;

ZEPHIR_INIT_CLASS(stub_10__closure);

PHP_METHOD(stub_10__closure, __invoke);

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_10__closure___invoke, 0, 0, 1)
	ZEND_ARG_INFO(0, config)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(stub_10__closure_method_entry) {
	PHP_ME(stub_10__closure, __invoke, arginfo_stub_10__closure___invoke, ZEND_ACC_PUBLIC|ZEND_ACC_FINAL)
	PHP_FE_END
};
