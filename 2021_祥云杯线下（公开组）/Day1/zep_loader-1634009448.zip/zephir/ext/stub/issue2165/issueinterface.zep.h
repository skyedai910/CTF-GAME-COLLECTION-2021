
extern zend_class_entry *stub_issue2165_issueinterface_ce;

ZEPHIR_INIT_CLASS(Stub_Issue2165_IssueInterface);

