
extern zend_class_entry *stub_issue893_ce;

ZEPHIR_INIT_CLASS(Stub_Issue893);

