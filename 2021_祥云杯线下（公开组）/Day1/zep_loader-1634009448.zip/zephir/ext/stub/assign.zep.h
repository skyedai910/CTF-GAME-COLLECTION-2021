
extern zend_class_entry *stub_assign_ce;

ZEPHIR_INIT_CLASS(Stub_Assign);

PHP_METHOD(Stub_Assign, getTestVar);
PHP_METHOD(Stub_Assign, getMyArray);
PHP_METHOD(Stub_Assign, testAssign1);
PHP_METHOD(Stub_Assign, testAssign2);
PHP_METHOD(Stub_Assign, testAssign3);
PHP_METHOD(Stub_Assign, testAssign4);
PHP_METHOD(Stub_Assign, testAssign5);
PHP_METHOD(Stub_Assign, testAssign6);
PHP_METHOD(Stub_Assign, testAssign7);
PHP_METHOD(Stub_Assign, testAssign8);
PHP_METHOD(Stub_Assign, testAssign9);
PHP_METHOD(Stub_Assign, testAssign10);
PHP_METHOD(Stub_Assign, testAssign11);
PHP_METHOD(Stub_Assign, testAssign12);
PHP_METHOD(Stub_Assign, testAssign13);
PHP_METHOD(Stub_Assign, testAssign14);
PHP_METHOD(Stub_Assign, testAssign15);
PHP_METHOD(Stub_Assign, testAssign16);
PHP_METHOD(Stub_Assign, testAssign17);
PHP_METHOD(Stub_Assign, testAssign18);
PHP_METHOD(Stub_Assign, testAssign19);
PHP_METHOD(Stub_Assign, testAssign20);
PHP_METHOD(Stub_Assign, testAssign21);
PHP_METHOD(Stub_Assign, testAssign22);
PHP_METHOD(Stub_Assign, testAssign23);
PHP_METHOD(Stub_Assign, testAssign24);
PHP_METHOD(Stub_Assign, testAssign25);
PHP_METHOD(Stub_Assign, testAssign26);
PHP_METHOD(Stub_Assign, testAssign27);
PHP_METHOD(Stub_Assign, testAssign28);
PHP_METHOD(Stub_Assign, testAssign29);
PHP_METHOD(Stub_Assign, testAssign30);
PHP_METHOD(Stub_Assign, testAssign31);
PHP_METHOD(Stub_Assign, testAssign32);
PHP_METHOD(Stub_Assign, testAssign33);
PHP_METHOD(Stub_Assign, testAssign34);
PHP_METHOD(Stub_Assign, testAssign35);
PHP_METHOD(Stub_Assign, testAssign36);
PHP_METHOD(Stub_Assign, testAssign37);
PHP_METHOD(Stub_Assign, testAssign38);
PHP_METHOD(Stub_Assign, testAssign39);
PHP_METHOD(Stub_Assign, testAssign40);
PHP_METHOD(Stub_Assign, testAssign41);
PHP_METHOD(Stub_Assign, testAssign42);
PHP_METHOD(Stub_Assign, testAssign43);
PHP_METHOD(Stub_Assign, testAssign44);
PHP_METHOD(Stub_Assign, testPropertyAssign1);
PHP_METHOD(Stub_Assign, testPropertyAssign2);
PHP_METHOD(Stub_Assign, testPropertyIncr1);
PHP_METHOD(Stub_Assign, testPropertyAddAssign1);
PHP_METHOD(Stub_Assign, testPropertyAddAssign2);
PHP_METHOD(Stub_Assign, testPropertyAssignValuePlus1);
PHP_METHOD(Stub_Assign, testPropertyDecr);
PHP_METHOD(Stub_Assign, testPropertySubAssign1);
PHP_METHOD(Stub_Assign, testPropertySubAssign2);
PHP_METHOD(Stub_Assign, testPropertyMulAssign1);
PHP_METHOD(Stub_Assign, testPropertyMulAssign2);
PHP_METHOD(Stub_Assign, testPropertyAssignStringConcat);
PHP_METHOD(Stub_Assign, testPropertyArray1);
PHP_METHOD(Stub_Assign, testPropertyArray2);
PHP_METHOD(Stub_Assign, testPropertyArray3);
PHP_METHOD(Stub_Assign, testPropertyArray4);
PHP_METHOD(Stub_Assign, testPropertyArray5);
PHP_METHOD(Stub_Assign, testPropertyArray6);
PHP_METHOD(Stub_Assign, testPropertyArray7);
PHP_METHOD(Stub_Assign, testPropertyArray8);
PHP_METHOD(Stub_Assign, testPropertyArray9);
PHP_METHOD(Stub_Assign, testPropertyArray10);
PHP_METHOD(Stub_Assign, testPropertyArray11);
PHP_METHOD(Stub_Assign, testPropertyArray12);
PHP_METHOD(Stub_Assign, testPropertyArray13);
PHP_METHOD(Stub_Assign, testPropertyArray14);
PHP_METHOD(Stub_Assign, testStaticPropertyAssign1);
PHP_METHOD(Stub_Assign, testStaticPropertyAssign2);
PHP_METHOD(Stub_Assign, testStaticPropertyArray1);
PHP_METHOD(Stub_Assign, testStaticPropertyArray2);
PHP_METHOD(Stub_Assign, testStaticPropertyArray3);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayAppend);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayMutli1);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayMutli2);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayMutli3);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayMulti4);
PHP_METHOD(Stub_Assign, testStaticPropertyArrayAppend1);
PHP_METHOD(Stub_Assign, testArrayVarAssign1);
PHP_METHOD(Stub_Assign, testArrayVarAssign2);
PHP_METHOD(Stub_Assign, testArrayProperty);
PHP_METHOD(Stub_Assign, testGlobalVarAssign);
PHP_METHOD(Stub_Assign, testConstantKeyAssign);
PHP_METHOD(Stub_Assign, testArrayBoolExpressionAssign);
PHP_METHOD(Stub_Assign, testAssignBitwiseX);
PHP_METHOD(Stub_Assign, testAssignSuperGlobals);
PHP_METHOD(Stub_Assign, testAssignSuperGlobalsSERVER);
PHP_METHOD(Stub_Assign, testAssignSuperGlobalsGET);
PHP_METHOD(Stub_Assign, issue597);

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_gettestvar, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_getmyarray, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign1, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign2, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign3, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign4, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign5, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign6, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign7, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign8, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign9, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign10, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign11, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign12, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign13, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign14, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign15, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign16, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign17, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign18, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign19, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign20, 0, 0, IS_NULL, 1)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign21, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign22, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign23, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign24, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign25, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign26, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign27, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign28, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign29, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign30, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign31, 0, 0, IS_DOUBLE, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign32, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign33, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign34, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign35, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign36, 0, 0, _IS_BOOL, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign37, 0, 0, IS_ARRAY, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign38, 0, 1, IS_ARRAY, 0)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign39, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign40, 0, 0, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign41, 0, 1, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, num, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign42, 0, 1, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, num, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign43, 0, 1, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, num, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_stub_assign_testassign44, 0, 1, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, num, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyassign1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyassign2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyincr1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyaddassign1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyaddassign2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyassignvalueplus1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertydecr, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertysubassign1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertysubassign2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertymulassign1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertymulassign2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyassignstringconcat, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray3, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray4, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray5, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, index, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray6, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray7, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray8, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray9, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, index, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray10, 0, 0, 1)
	ZEND_ARG_TYPE_INFO(0, index, IS_STRING, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray11, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray12, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray13, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testpropertyarray14, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyassign1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyassign2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarray1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarray2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarray3, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarrayappend, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarraymutli1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarraymutli2, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarraymutli3, 0, 0, 1)
	ZEND_ARG_INFO(0, index)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarraymulti4, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_teststaticpropertyarrayappend1, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testarrayvarassign1, 0, 0, 2)
	ZEND_ARG_INFO(0, index)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testarrayvarassign2, 0, 0, 2)
	ZEND_ARG_INFO(0, index)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testarrayproperty, 0, 0, 2)
	ZEND_ARG_INFO(0, index)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testglobalvarassign, 0, 0, 2)
	ZEND_ARG_INFO(0, index)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testconstantkeyassign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testarrayboolexpressionassign, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testassignbitwisex, 0, 0, 2)
	ZEND_ARG_TYPE_INFO(0, a, IS_LONG, 0)
	ZEND_ARG_TYPE_INFO(0, b, IS_LONG, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testassignsuperglobals, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testassignsuperglobalsserver, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_testassignsuperglobalsget, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_stub_assign_issue597, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEPHIR_INIT_FUNCS(stub_assign_method_entry) {
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, getTestVar, arginfo_stub_assign_gettestvar, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, getTestVar, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, getMyArray, arginfo_stub_assign_getmyarray, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, getMyArray, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testAssign1, arginfo_stub_assign_testassign1, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign2, arginfo_stub_assign_testassign2, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign3, arginfo_stub_assign_testassign3, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign4, arginfo_stub_assign_testassign4, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign5, arginfo_stub_assign_testassign5, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign6, arginfo_stub_assign_testassign6, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign7, arginfo_stub_assign_testassign7, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign8, arginfo_stub_assign_testassign8, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign9, arginfo_stub_assign_testassign9, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign10, arginfo_stub_assign_testassign10, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign11, arginfo_stub_assign_testassign11, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign12, arginfo_stub_assign_testassign12, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign13, arginfo_stub_assign_testassign13, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign14, arginfo_stub_assign_testassign14, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign15, arginfo_stub_assign_testassign15, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign16, arginfo_stub_assign_testassign16, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign17, arginfo_stub_assign_testassign17, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign18, arginfo_stub_assign_testassign18, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign19, arginfo_stub_assign_testassign19, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign20, arginfo_stub_assign_testassign20, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign21, arginfo_stub_assign_testassign21, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign22, arginfo_stub_assign_testassign22, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign23, arginfo_stub_assign_testassign23, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign24, arginfo_stub_assign_testassign24, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign25, arginfo_stub_assign_testassign25, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign26, arginfo_stub_assign_testassign26, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign27, arginfo_stub_assign_testassign27, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign28, arginfo_stub_assign_testassign28, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign29, arginfo_stub_assign_testassign29, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign30, arginfo_stub_assign_testassign30, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign31, arginfo_stub_assign_testassign31, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign32, arginfo_stub_assign_testassign32, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign33, arginfo_stub_assign_testassign33, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign34, arginfo_stub_assign_testassign34, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign35, arginfo_stub_assign_testassign35, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign36, arginfo_stub_assign_testassign36, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign37, arginfo_stub_assign_testassign37, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign38, arginfo_stub_assign_testassign38, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign39, arginfo_stub_assign_testassign39, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign40, arginfo_stub_assign_testassign40, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign41, arginfo_stub_assign_testassign41, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign42, arginfo_stub_assign_testassign42, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign43, arginfo_stub_assign_testassign43, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testAssign44, arginfo_stub_assign_testassign44, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAssign1, arginfo_stub_assign_testpropertyassign1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAssign1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAssign2, arginfo_stub_assign_testpropertyassign2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAssign2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyIncr1, arginfo_stub_assign_testpropertyincr1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyIncr1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAddAssign1, arginfo_stub_assign_testpropertyaddassign1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAddAssign1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAddAssign2, arginfo_stub_assign_testpropertyaddassign2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAddAssign2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAssignValuePlus1, arginfo_stub_assign_testpropertyassignvalueplus1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAssignValuePlus1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyDecr, arginfo_stub_assign_testpropertydecr, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyDecr, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertySubAssign1, arginfo_stub_assign_testpropertysubassign1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertySubAssign1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertySubAssign2, arginfo_stub_assign_testpropertysubassign2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertySubAssign2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyMulAssign1, arginfo_stub_assign_testpropertymulassign1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyMulAssign1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyMulAssign2, arginfo_stub_assign_testpropertymulassign2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyMulAssign2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyAssignStringConcat, arginfo_stub_assign_testpropertyassignstringconcat, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyAssignStringConcat, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray1, arginfo_stub_assign_testpropertyarray1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray2, arginfo_stub_assign_testpropertyarray2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray3, arginfo_stub_assign_testpropertyarray3, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray3, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testPropertyArray4, arginfo_stub_assign_testpropertyarray4, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray5, arginfo_stub_assign_testpropertyarray5, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray6, arginfo_stub_assign_testpropertyarray6, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray6, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray7, arginfo_stub_assign_testpropertyarray7, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray7, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testPropertyArray8, arginfo_stub_assign_testpropertyarray8, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray9, arginfo_stub_assign_testpropertyarray9, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray10, arginfo_stub_assign_testpropertyarray10, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray11, arginfo_stub_assign_testpropertyarray11, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray12, arginfo_stub_assign_testpropertyarray12, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testPropertyArray13, arginfo_stub_assign_testpropertyarray13, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testPropertyArray14, arginfo_stub_assign_testpropertyarray14, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testPropertyArray14, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyAssign1, arginfo_stub_assign_teststaticpropertyassign1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyAssign1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyAssign2, arginfo_stub_assign_teststaticpropertyassign2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyAssign2, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArray1, arginfo_stub_assign_teststaticpropertyarray1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArray1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArray2, arginfo_stub_assign_teststaticpropertyarray2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArray2, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testStaticPropertyArray3, arginfo_stub_assign_teststaticpropertyarray3, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArrayAppend, arginfo_stub_assign_teststaticpropertyarrayappend, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArrayAppend, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArrayMutli1, arginfo_stub_assign_teststaticpropertyarraymutli1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArrayMutli1, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArrayMutli2, arginfo_stub_assign_teststaticpropertyarraymutli2, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArrayMutli2, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testStaticPropertyArrayMutli3, arginfo_stub_assign_teststaticpropertyarraymutli3, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArrayMulti4, arginfo_stub_assign_teststaticpropertyarraymulti4, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArrayMulti4, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testStaticPropertyArrayAppend1, arginfo_stub_assign_teststaticpropertyarrayappend1, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testStaticPropertyArrayAppend1, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testArrayVarAssign1, arginfo_stub_assign_testarrayvarassign1, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testArrayVarAssign2, arginfo_stub_assign_testarrayvarassign2, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testArrayProperty, arginfo_stub_assign_testarrayproperty, ZEND_ACC_PUBLIC)
	PHP_ME(Stub_Assign, testGlobalVarAssign, arginfo_stub_assign_testglobalvarassign, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testConstantKeyAssign, arginfo_stub_assign_testconstantkeyassign, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testConstantKeyAssign, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testArrayBoolExpressionAssign, arginfo_stub_assign_testarrayboolexpressionassign, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testArrayBoolExpressionAssign, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_ME(Stub_Assign, testAssignBitwiseX, arginfo_stub_assign_testassignbitwisex, ZEND_ACC_PUBLIC)
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testAssignSuperGlobals, arginfo_stub_assign_testassignsuperglobals, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testAssignSuperGlobals, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testAssignSuperGlobalsSERVER, arginfo_stub_assign_testassignsuperglobalsserver, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testAssignSuperGlobalsSERVER, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, testAssignSuperGlobalsGET, arginfo_stub_assign_testassignsuperglobalsget, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, testAssignSuperGlobalsGET, NULL, ZEND_ACC_PUBLIC)
#endif
#if PHP_VERSION_ID >= 80000
	PHP_ME(Stub_Assign, issue597, arginfo_stub_assign_issue597, ZEND_ACC_PUBLIC)
#else
	PHP_ME(Stub_Assign, issue597, NULL, ZEND_ACC_PUBLIC)
#endif
	PHP_FE_END
};
