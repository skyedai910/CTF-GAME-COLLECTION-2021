
extern zend_class_entry *stub_router_exception_ce;

ZEPHIR_INIT_CLASS(Stub_Router_Exception);

