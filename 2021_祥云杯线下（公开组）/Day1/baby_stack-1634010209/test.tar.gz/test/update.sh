mv -f pwn /home/ctf/pwn
chmod +x /home/ctf/pwn